// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#include "Puzzle2.h"


IMPLEMENT_PRIMARY_GAME_MODULE(FDefaultGameModuleImpl, Puzzle2, "Puzzle2");



 